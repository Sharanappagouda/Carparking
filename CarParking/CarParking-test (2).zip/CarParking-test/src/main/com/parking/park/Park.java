package main.com.parking.park;

import main.com.parking.exceptions.CoordinatesoutofRange;

public class Park {

	public int canFitInSlot(int positionX, int positionY, String orientation, String movement,int length,int breadth, int newPosition) throws CoordinatesoutofRange{
		int newX=0;
		int newY=0;
		try{
			switch(orientation){
				case "east":	if(movement.equalsIgnoreCase("forward")){
									 if((positionX + newPosition)>= length)
										 throw new CoordinatesoutofRange(positionX + newPosition);
									 else
										 newX = positionX + newPosition;
								}else if(movement.equalsIgnoreCase("backward")){
									if((positionX - newPosition) <= 0)
										throw new CoordinatesoutofRange(positionX - newPosition);
									else
										newX = positionX - newPosition;
								}	
								break;
				case "south":	if(movement.equalsIgnoreCase("forward")){
									if((positionY - newPosition) <= 0)
										 throw new CoordinatesoutofRange(positionY - newPosition);
									else
										newY = positionY - newPosition;
								}else if(movement.equalsIgnoreCase("backward")){
									if((positionY + newPosition) >= breadth)
										throw new CoordinatesoutofRange(positionY + newPosition);
									else
										newY = positionY + newPosition;
								}	
								break;
				case "west":	if(movement.equalsIgnoreCase("forward")){
					 				if((positionX - newPosition)<= 0)
					 					throw new CoordinatesoutofRange(positionX - newPosition);			
									else
										newX = positionX - newPosition;
								}else if(movement.equalsIgnoreCase("backward")){
									if((positionX + newPosition) >= length)
										throw new CoordinatesoutofRange(positionX + newPosition);
									else
										newX = positionX + newPosition;
								}	
								break;
				case "north":	if(movement.equalsIgnoreCase("forward")){
									if((positionY + newPosition) >= breadth)
										throw new CoordinatesoutofRange(positionY + newPosition);
									else
										newY = positionY + newPosition;
								}else if(movement.equalsIgnoreCase("backward")){
									if((positionY - newPosition) <= 0)
										throw new CoordinatesoutofRange(positionY + newPosition);
									else
										newY = positionY - newPosition;
								}	
								break;

				default :		break;	
			}
			}catch (CoordinatesoutofRange e){
				throw e;
			}
//		System.out.println("can can be parked at the given coordinates");
		if(newX == 0){
			System.out.println("Car can be parked at new Y location");
		return newY;
		}else{
			System.out.println("Car can be parked at new X location");
		return newX;
		}
	}
	
	public String orientationdegrees(String orientation,int degrees) {
		
		String newOrientation= null;
		switch(orientation){
		case "north" : if(degrees == 90){
							newOrientation = "east";
						}else if(degrees == 180){
							newOrientation = "south";
						}else if(degrees == 270){
							newOrientation="west";
						}else{
							newOrientation = "north";
						}
		case "east" : if(degrees == 90){
							newOrientation = "south";
						}else if(degrees == 180){
							newOrientation = "west";
						}else if(degrees == 270){
							newOrientation="north";
						}else{
							newOrientation = "east";
						}
		case "south" : if(degrees == 90){
							newOrientation = "west";
						}else if(degrees == 180){
							newOrientation = "north";
						}else if(degrees == 270){
							newOrientation="east";
						}else{
							newOrientation = "south";
						}
		case "west" : if(degrees == 90){
							newOrientation = "north";
						}else if(degrees == 180){
							newOrientation = "east";
						}else if(degrees == 270){
							newOrientation="south";
						}else{
							newOrientation = "west";
						}
			
			
		}
		return newOrientation;
	}
}
