package main.com.parking.exceptions;

@SuppressWarnings("serial")
public class DegreesException extends Exception {

	   private int degrees;
	   public DegreesException(int degrees)
	   {
	      this.degrees = degrees;
	   } 
	   public int getdegrees()
	   {
	      return degrees;
	   }
}
