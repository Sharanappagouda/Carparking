package test.com.parking.main;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import test.com.parking.park.ParkTest;
import test.com.parking.validations.ValidationsTest1;
import test.com.parking.validations.ValidationsTest2;
import test.com.parking.validations.ValidationsTest3;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	ValidationsTest1.class,
	ValidationsTest2.class,
	ValidationsTest3.class,
	ParkTest.class
})
public class CarSuite {

}
